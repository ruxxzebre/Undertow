import { app, BrowserWindow } from "electron";

const main = () => {
	const window = new BrowserWindow({
		width: 800, height: 700
	})
}
