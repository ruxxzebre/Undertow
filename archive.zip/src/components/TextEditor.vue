<script setup>
import { Editor } from '@toast-ui/vue-editor';
</script>

<template>
	<Editor />
</template>