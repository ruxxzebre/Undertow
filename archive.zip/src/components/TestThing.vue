<template>
  <div class="pane">
    <table class="table-striped">
      <thead>
        <tr>
          <th>Name</th>
          <th>Kind</th>
          <th>Date Modified</th>
          <th>Author</th>
        </tr>
      </thead>
      <tbody>
        <tr class="file_arq">
          <td>bars.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>base.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>button-groups.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>buttons.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>docs.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>forms.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>grid.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>icons.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>images.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>lists.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>mixins.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>navs.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>normalize.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>photon.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>tables.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>tabs.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>utilities.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
        <tr class="file_arq">
          <td>variables.scss</td>
          <td>Document</td>
          <td>Oct 13, 2015</td>
          <td>connors</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
