<script setup>
import TestThing from '@/components/TestThing.vue';
</script>

<template>
  <TestThing />
</template>